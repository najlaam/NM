
public interface IntExample {
	
	
	public void sayHello();

}
