
public class HelloWorld implements IntExample{

	public static void main(String[] args) {


HelloWorld hw = new HelloWorld();
hw.sayHello();
	}

	@Override
	public void sayHello() {
		// TODO Auto-generated method stub
		System.out.println("Hello world!");
	}

}
